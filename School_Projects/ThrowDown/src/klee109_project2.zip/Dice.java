
public class Dice {
	
	int[] dice = new int[5];
	public Dice(int a,int b,int c,int d,int e){
		this.dice[0] = a;
		this.dice[1] = b;
		this.dice[2] = c;
		this.dice[3] = d;
		this.dice[4] = e;
		
	}
	int a = dice[0];
	int b = dice[1];
	int c = dice[2];
	int d = dice[3];
	int e = dice[4];
	
	

}
