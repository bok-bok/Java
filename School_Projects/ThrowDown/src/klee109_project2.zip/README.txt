You can choose simulate or classify as a command line argument

If you choose classify,  program will ask you "what is your dices?". 
You type your hands of dice. Ex) 11134 
Then, program classify your hands and tell what score you earned. 

If you choose simulate, the program will ask you "how many output do you want to check?" 
You enter any number, and you can see frequency and average score of outcomes.

