When game starts game describes condition of catapult and where is target. 
Then it asks user What is your next move?.
Then, user can choose one of game commands to proceed the game.


Game Commands

	Upper or Lower letter does not matter in game command	

	set angle x
		changes the angle to X degree
	set velocity x
		changes the velocity to X m/s
	reset
		resets the game except best score
	fire
		fires the shot
	score
		shows current and best score
	inspect
		describes the catapult and target
	quit
		quits the game
	

Cheat commands

	cheat 
		shows exact catapult quality and target distance
	cheat x
		shows exact catapult quality and target distance
		and set x as remaining shots
	cheat x y 
		shows exact catapult quality and target distance
		and set x as remaining shots
		and set catapult quality as y
	cheat x y z
		shows exact catapult quality and target distance
		and set x as remaining shots
		and set catapult quality as y
		and set target distance to z


How to continue play after using all shots

	When you used all shots you have two choices: cheat and reset.
	If you use cheat to gain more shots you can continue with current score, but if 	you choose reset, you start new round with 0 score.
